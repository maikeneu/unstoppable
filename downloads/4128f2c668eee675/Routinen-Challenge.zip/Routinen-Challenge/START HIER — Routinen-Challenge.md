# Deine 7-Tage-Routinen-Challenge

Schön, dass du hier bist. In diesem Ordner liegt alles, was du für die nächsten sieben Tage brauchst. Du musst nichts Technisches können und du kannst nichts kaputt machen. Nichts hiervon überschreibt etwas, das du schon gebaut hast. Es kommt nur Neues dazu.

In dieser Woche passieren zwei Dinge. Dein System fängt an, ohne dich zu arbeiten: Es begrüßt dich morgens mit dem, was heute zählt, es sammelt tagsüber für dich, und es macht abends deinen Tag rund. Und du bekommst deine eigene Seite im Netz, die aussieht wie du und die du selbst ändern kannst, wann immer du willst.

Pro Tag brauchst du zehn bis zwanzig Minuten. Mehr nicht.

## Was drin ist

- **7-Tage-Routinen-Challenge.pdf** — dein Fahrplan für die Woche. Lies ihn in Ruhe, wann du magst.
- **Anleitung Deine Seite.pdf** — zum Nachschlagen, wenn ich nicht daneben sitze: eigene Bilder einbinden, Texte ändern, die Seite ins Netz bringen (auch bei IONOS) und der Testdurchlauf am Ende. Brauchst du erst ab Tag 5.
- Zwei Ordner mit deinen neuen Fähigkeiten und deinem neuen Bereich. Die legt dein Assistent gleich selbst an die richtige Stelle.

## Der einfache Weg

1. Leg diesen ganzen Ordner **„Routinen-Challenge"** in deine **Inbox** (deinen Handy-Posteingang oder den Ordner `01 Inbox` in deinem zweiten Gehirn).
2. Öffne deinen Assistenten und sag ihm diesen einen Satz:

> **„In meiner Inbox liegt die Routinen-Challenge. Richte sie bitte für mich ein, ohne etwas zu überschreiben."**

Dein Assistent macht dann alles Weitere. Er sagt dir Bescheid, wenn alles bereit ist.

3. Danach startest du mit:

> **„Starte meine Routinen-Challenge."**

Ab hier führt dich dein System Tag für Tag. Es fragt dich viel, und das ist Absicht: Je genauer du antwortest, desto mehr fühlen sich deine Routinen später nach dir an und nicht nach Standard.

---

## Anweisung an den Assistenten (bitte stehen lassen)

Du richtest der Nutzerin die Routinen-Challenge in ihrem bestehenden Vault ein. **Oberste Regel: nur hinzufügen, niemals überschreiben oder löschen.** Sprich warm und auf Deutsch, ohne Fachbegriffe. Geh so vor:

1. **Die neuen Fähigkeiten anlegen.** Kopiere die fünf Ordner aus `1 — Neue Faehigkeiten/` nach `.claude/skills/` in ihrem Vault:
   `routinen-challenge`, `mein-morgen-briefing`, `mein-abend-bericht`, `mein-podcast`, `meine-seite`.
   Prüfe vorher, ob es einen dieser Ordner schon gibt. Falls ja, überschreib ihn nicht, sondern sag es ihr und frag, wie sie vorgehen möchte.

2. **Den Bereich „Meine Routinen" anlegen.** Kopiere den Ordner `2 — Meine Routinen/` als `03 Bereiche/Meine Routinen/` in ihren Vault. Falls es diesen Bereich schon gibt, nichts überschreiben, sondern nachfragen und nur die fehlenden Dateien ergänzen.

3. **Die Team-Liste ergänzen (nur ergänzen).** Falls `00 Kontext/Mein Team.md` existiert, häng unter „Meine Helfer und Routinen" die neuen Zeilen an: Morgen-Briefing, Abend-Bericht, Podcast, meine Seite. Ersetze nichts, was schon dort steht.

4. **Aufräumen und Bescheid geben.** Wenn alles liegt, kannst du den eingelegten Ordner „Routinen-Challenge" aus der Inbox entfernen (die PDF darf sie behalten). Sag ihr dann in einem Satz, was du eingerichtet hast, und dass sie mit „Starte meine Routinen-Challenge" loslegen kann.

5. **Wichtig:** Die neuen Fähigkeiten werden erst wirksam, wenn die native App einmal neu gestartet wurde. Weise sie freundlich darauf hin, die App einmal zu schließen und wieder zu öffnen, bevor sie startet.

Falls dir etwas unklar ist oder eine Datei schon existiert: nicht raten, nicht überschreiben, sondern kurz nachfragen.
