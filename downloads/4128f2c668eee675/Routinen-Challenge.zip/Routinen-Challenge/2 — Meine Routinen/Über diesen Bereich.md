---
tags: [routinen]
status: aktiv
---

# Meine Routinen

Hier wohnt alles, was mein System für mich tut, ohne dass ich danach frage.

Eine Routine ist nichts Technisches. Es ist eine Verabredung: Ich sage einmal, was ich wann brauche, und ab da kommt es von selbst. Ändern kann ich das jederzeit, indem ich es einfach sage.

## Was hier entsteht

- **Briefings/** — mein Morgen-Briefing, für jeden Tag eine Datei.
- **Berichte/** — mein Abend-Bericht, für jeden Tag eine Datei.
- **Podcast/** — meine Folgen zum Lesen und zum Hören.
- **Heute.md** — die eine Datei, in der immer der aktuelle Stand steht. Die kann ich mir auf den Schreibtisch legen.
- **Mein Erfolgsbuch.md** — was gut lief, Tag für Tag gesammelt. Nach ein paar Wochen von oben nach unten lesen.
- **Steckbriefe** — was ich meinem System über meine Routinen gesagt habe. Da schaut es nach, wenn es etwas für mich baut.
- **Challenge-Fortschritt.md** — wo ich in meiner Routinen-Challenge stehe.

## Drei Dinge, die ich wissen sollte

1. Routinen laufen nur, wenn mein Rechner wach und meine App geöffnet ist. Ein verpasster Tag ist kein Problem, es wird nachgeholt.
2. Was ich nicht lese, wird gestrichen. Lieber drei Zeilen, die ich wirklich anschaue, als eine Seite, die ich überblättere.
3. Ich muss nichts davon selbst pflegen. Ich sage, was mir fehlt, und mein System ändert es.

## Wenn morgens nichts kam

In dieser Reihenfolge prüfen: War der Rechner an? War die App offen? Wenn beides ja, sage ich einfach „mein Briefing kam heute nicht", und mein System schaut nach und holt es nach.
