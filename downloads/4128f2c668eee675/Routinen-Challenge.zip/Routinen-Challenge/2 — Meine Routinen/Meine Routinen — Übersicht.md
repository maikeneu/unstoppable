---
tags: [routinen]
status: aktiv
---

# Meine Routinen auf einen Blick

Diese Tabelle füllt sich im Lauf der Challenge. Mein System trägt jede neue Routine hier ein, damit ich immer sehe, was gerade für mich läuft.

| Routine | Wann | Was sie mir bringt | Wo das Ergebnis liegt | Seit |
|---|---|---|---|---|
| Mein Morgen-Briefing | | | `Briefings/` | |
| Mein Abend-Bericht | | | `Berichte/` | |
| Meine Rechercheure | | | im Morgen-Briefing | |
| Mein Podcast | | | `Podcast/` | |

## Was ich sagen kann, wenn ich etwas ändern will

- „Ich will morgens auch noch wissen, ob …"
- „Das im Briefing lese ich nie, lass das weg."
- „Mein Abend-Bericht kommt zu spät, mach ihn eine Stunde früher."
- „Mein Podcast war zu lang."
- „Schalt die Rechercheurin für diese Woche ab, ich bin im Urlaub."

Ich muss nichts davon technisch formulieren. Ein Satz reicht.
