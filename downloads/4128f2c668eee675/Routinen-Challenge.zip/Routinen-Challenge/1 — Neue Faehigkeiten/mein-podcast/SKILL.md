---
name: mein-podcast
description: Baut der Nutzerin ihren eigenen täglichen Podcast: erst das Hördokument in ihrer Lage, dann daraus die Audio-Folge zum Anhören. Aktiviere bei "bau mir meinen Podcast", "meine Podcast-Folge für heute", "mein Podcast ändern", "Podcast anhören".
user-invocable: true
---

# Dein Podcast

## Was dieser Skill macht

Er schreibt ihr jeden Tag eine kurze Folge, die genau zu ihrer Lage passt, und macht daraus etwas zum Hören. Sie hört unterwegs zehn bis fünfzehn Minuten und hat danach einen Gedanken, den sie heute anwenden kann.

## Die wichtigste Regel

Ein Podcast, der allgemein bleibt, wird nicht gehört. Der Wert liegt darin, dass die Folge **ihre** Lage kennt: ihre Woche, ihre offenen Punkte, ihre Fragen. Nutze dafür, was in ihrem zweiten Gehirn steht, und schreib niemals etwas hinein, das sie dir nicht gesagt hat.

Sprich warm und auf Deutsch, ohne Fachbegriffe.

---

## Teil 1 — Das Interview (nur beim ersten Mal)

Immer nur eine Frage, notiert in `03 Bereiche/Meine Routinen/Mein Podcast (Steckbrief).md`.

1. „Wann hörst du? Auto, Bahn, Spaziergang, Küche?"
2. „Wie lang darf eine Folge sein?"
3. „Worüber willst du hören? Neues aus deinem Fach, Führung und Unternehmerisches, Persönliches und Haltung, oder eine Mischung?"
4. „Willst du eher Wissen oder eher Ermutigung?"
5. „Soll vorkommen, was bei dir gerade wirklich los ist, oder soll es allgemein bleiben?"
6. „Gibt es Bücher, Denkerinnen oder Stimmen, von denen du gern etwas hören würdest?"
7. „Duzen oder siezen? Soll dein Name vorkommen?"
8. „Was willst du am Ende jeder Folge haben: einen Gedanken zum Mitnehmen, eine Frage an dich selbst, oder einen konkreten Schritt für heute?"
9. „Gibt es Themen, die darin nichts zu suchen haben?"

Wenn sie bei Frage 3 unsicher ist, schlag ihr eine Rotation vor: an manchen Tagen Fachliches, an manchen Unternehmerisches, an manchen Haltung. Leg die Rotation dann in `03 Bereiche/Meine Routinen/Podcast-Rotation.md` ab und hak ab, was schon dran war.

---

## Teil 2 — Die Folge schreiben (das passiert jeden Tag)

1. **Quellen lesen:** ihr Steckbrief, die Rotation, ihre letzten Tagesnotizen, ihre offenen Punkte, was ihre Rechercheure gefunden haben.
2. **Folge schreiben** nach `03 Bereiche/Meine Routinen/Podcast/JJJJ-MM-TT <Thema>.md`, immer in fünf Teilen:
   - **Der Gedanke:** worum es heute geht, in einfachen Worten.
   - **Bei dir:** wie das mit ihrer aktuellen Lage zusammenhängt, konkret und mit ihren Worten.
   - **Drei Schritte:** was sie heute damit machen kann, klein genug für einen vollen Tag.
   - **Eine Frage:** eine ehrliche Frage an sie, keine rhetorische.
   - **Die Stolperfalle:** woran es typischerweise scheitert.
3. **Länge:** an ihrer Antwort aus Frage 2 ausrichten. Als Faustregel ergeben etwa 1200 Wörter eine Folge von ungefähr zehn Minuten.

Das ist der Teil, der immer funktioniert, auch ohne Browser und ohne Internet-Dienste.

---

## Teil 3 — Daraus etwas zum Hören machen

Zum Hören wird die Folge in einem Dienst erzeugt, der aus Text ein Gespräch macht (NotebookLM von Google). Dafür braucht es den Browser Chrome mit der Claude-Erweiterung und ihre Anmeldung bei Google.

**So geht es:**
1. Prüf zuerst, ob ein Chrome-Browser verbunden ist. Wenn nicht, geh direkt zum Abschnitt „Wenn kein Browser da ist".
2. Öffne über die Chrome-Erweiterung `notebooklm.google.com`. Nutze dafür ausschließlich die Chrome-Erweiterung, nicht andere Browser-Werkzeuge: nur dort ist sie bei Google angemeldet.
3. Leg ein neues Notizbuch an und füg den Text der heutigen Folge als Quelle ein.
4. Erzeuge eine Audio-Zusammenfassung auf Deutsch. Gib als Hinweis für die Sprecher mit: Es ist ein persönlicher Podcast für eine einzelne Zuhörerin, auf Deutsch, mit Fokus auf den drei Schritten, ruhig und zugewandt, keine Werbesprache.
5. Sag ihr, wenn die Folge fertig ist, und wo sie sie findet. Halte den Link in der Folgen-Datei fest.

**Wenn kein Browser da ist:**
Speicher die Folge trotzdem, schreib oben in die Datei die Zeile `> Zum Hören noch offen` und trag sie in `03 Bereiche/Meine Routinen/Podcast/_offen.md` ein. Sag ihr in einem Satz, dass die Folge zum Lesen bereitliegt und das Hören nachgeholt wird, sobald Chrome offen ist. Kein Drama, keine Fehlermeldung.

**Beim allerersten Mal:** Geh die Schritte gemeinsam mit ihr durch, während sie zuschaut. Danach weiß sie, was passiert, und kann es später auch selbst.

---

## Teil 4 — Als tägliche Routine

Wenn sie den Podcast täglich will:
1. Leg die Arbeitsanweisung in `~/.claude/scheduled-tasks/mein-podcast/SKILL.md` an.
2. Setz den Zeitplan mit dem Werkzeug für geplante Aufgaben auf eine Zeit deutlich vor ihrem Hören, damit die Folge fertig ist, wenn sie ins Auto steigt.
3. Erinnere sie einmal daran: Der Rechner muss dafür wach sein und ihre App geöffnet.

## Später ändern

Frag sie nach der ersten Woche: „Hast du wirklich gehört? Wo hast du abgeschaltet?" Wenn sie abbricht, liegt es fast immer an der Länge oder daran, dass die Folge zu allgemein war. Kürze und mach sie persönlicher, statt das Thema zu wechseln.
