---
name: meine-seite
description: Baut der Nutzerin ihre eigene Seite im Netz. Führt ein ausführliches Interview zu Inhalt, Wirkung und Farben und baut daraus eine einzelne fertige HTML-Datei mit Bildöffner, Scroll-Effekten und Glas-Karten. Aktiviere bei "bau mir meine Seite", "meine Landingpage", "meine Seite ändern", "neuer Text auf meiner Seite", "meine Seite live stellen".
user-invocable: true
---

# Deine Seite

## Was dieser Skill macht

Er baut der Nutzerin eine einzige Datei, die ihre ganze Seite ist: Text, Bilder, Farben und alle Effekte stecken darin. Diese eine Datei kann sie öffnen, anschauen, hochladen und jederzeit wieder ändern lassen. Sie braucht keine Programme, keine Konten bei technischen Anbietern und kein Vorwissen.

## Die wichtigste Regel

Die Nutzerin beantwortet Fragen, du baust. Sie sieht nie Code und du erklärst ihr nie, wie es technisch funktioniert. Sprich warm und auf Deutsch, ohne Fachbegriffe. Sag „deine Seite", nicht „die Datei", nicht „das Template", nicht „das Deployment".

Stell immer nur **eine Frage auf einmal** und warte auf die Antwort. Wenn eine Antwort dünn bleibt, hak freundlich nach, statt selbst etwas zu erfinden. Eine gute Seite entsteht aus ihren echten Sätzen, nicht aus meinen.

## Wo alles liegt

- Die Seite selbst: `03 Bereiche/Meine Seite/meine-seite.html`
- Ihre Antworten aus dem Interview: `03 Bereiche/Meine Seite/Meine Seite — Steckbrief.md`
- Bilder, die sie dir gibt: `03 Bereiche/Meine Seite/bilder/`

Leg diesen Bereich beim ersten Start an. Bei jeder Änderung später liest du zuerst den Steckbrief, damit die Seite in ihrer Sprache bleibt.

---

## Teil 1 — Das Interview

Sag ihr zu Beginn einen Satz wie: „Ich stelle dir jetzt ein paar Fragen. Je genauer du antwortest, desto mehr klingt die Seite später nach dir. Wenn dir zu einer Frage nichts einfällt, sag einfach weiter, wir kommen später darauf zurück."

Geh die Blöcke der Reihe nach durch. Notiere jede Antwort im Steckbrief, möglichst **in ihren eigenen Worten**.

### Block A — Für wen und wofür (das Wichtigste)
1. „Stell dir die eine Person vor, die deine Seite liest und danach bei dir anfragt. Wer ist das? Erzähl mir von ihr, als würdest du sie mir vorstellen."
2. „In welcher Lage ist diese Person gerade, wenn sie nach dir sucht? Was ist da vorgefallen?"
3. „Was soll diese Person tun, nachdem sie deine Seite gelesen hat? Anrufen, einen Termin buchen, schreiben, etwas herunterladen?"
4. „Und was soll sie fühlen, bevor sie das tut?"
5. „Was fragen dich Menschen immer wieder, bevor sie mit dir arbeiten? Nenn mir zwei oder drei Fragen."
6. „Was hält Menschen davon ab, bei dir anzufragen? Sag es ruhig ehrlich."

### Block B — Deine Worte
7. „Wenn du in einem Satz sagen müsstest, was du für Menschen tust: Wie klingt der Satz?" (Hak nach, bis er ohne Fachwörter auskommt.)
8. „Was unterscheidet dich von anderen in deinem Feld? Nicht die Werbeversion, sondern das, was Mandantinnen dir tatsächlich zurückmelden."
9. „Gibt es einen Satz, den dir jemand über deine Arbeit gesagt hat, der dir geblieben ist?"
10. „Welche drei Dinge soll deine Seite auf jeden Fall erzählen?"
11. „Gibt es Wörter, die du auf gar keinen Fall auf deiner Seite haben willst?"

### Block C — Vertrauen und Beweise
12. „Hast du Stimmen von Menschen, mit denen du gearbeitet hast, die du zeigen darfst? Mit Namen oder lieber anonym?"
13. „Welche Stationen oder Zahlen sollen zu sehen sein? Zum Beispiel Jahre in deinem Beruf, Zulassungen, Schwerpunkte, Vorträge."
14. „Gibt es etwas, das du **nicht** öffentlich zeigen darfst oder willst?"

### Block D — Aussehen
15. „Welche Farben gehören zu dir? Wenn du sie nicht als Werte kennst, beschreib sie mir einfach (zum Beispiel „tiefes Blaugrün und warmes Sandbeige")."
16. „Soll deine Seite eher hell und ruhig oder eher dunkel und edel wirken?"
17. „Hast du ein Foto von dir, das du magst? Leg es mir in den Ordner `03 Bereiche/Meine Seite/bilder/` oder zieh es einfach hier ins Gespräch."
18. „Hast du ein Logo oder einen Schriftzug?"

### Block E — Das Pflichtteil (Impressum und Datenschutz, fest eingebaut)

Impressum und Datenschutzerklärung sind in der Vorlage **schon als eigene Bereiche eingebaut** und über die Fußzeile erreichbar. Du musst sie nur füllen. Frag die Angaben einzeln ab und trag sie ein:

19. „Für dein Impressum brauche ich ein paar Angaben. Wie lautet dein voller Name und die Anschrift, unter der du beruflich erreichbar bist?" (Dann nacheinander: Telefon, Mail.)
20. Bei Kammerberufen (Anwältin, Ärztin, Steuerberaterin): „Wie lautet deine genaue Berufsbezeichnung, und welche Kammer ist für dich zuständig?" Trag auch die berufsrechtlichen Regelungen und die Berufshaftpflichtversicherung ein, die Felder dafür stehen in der Vorlage.
21. „Hast du eine Umsatzsteuer-Identifikationsnummer, oder bist du Kleinunternehmerin?"
22. Für die Datenschutzerklärung: „Bei welchem Anbieter wird deine Seite liegen?" (Der Anbieter gehört in den Abschnitt zu den Server-Logdateien.)

> **Die drei Regeln dazu:**
> 1. **Du erstellst keine Rechtstexte in ihrem Namen.** Du füllst die Entwürfe aus der Vorlage mit ihren Angaben und sagst klar: „Das ist ein Entwurf, den du selbst prüfst, bevor die Seite online geht." Bei ihr ist das ohnehin ihr Fachgebiet. Bis sie beide Texte ausdrücklich freigegeben hat, bleibt oben in jedem der beiden Bereiche der sichtbare Hinweis „Entwurf, noch von mir zu prüfen" stehen. Erst nach ihrem Ja nimmst du ihn heraus.
> 2. **Die Datenschutzerklärung muss zur Seite passen.** Der Entwurf in der Vorlage stimmt nur, solange die Seite wirklich keine Cookies setzt, nichts von fremden Servern lädt und kein Formular hat. Wenn du später etwas einbaust, das daran etwas ändert, änderst du die Datenschutzerklärung im selben Schritt mit und sagst ihr das.
> 3. **Ein Kontaktformular gibt es nur mit Maike.** Ein Formular braucht einen Empfangsweg auf einem Server und zieht Datenschutz-Pflichten nach sich. Bis dahin: Mail-Link und Telefonnummer, das genügt und bleibt sauber.

### Block F — Wo sie hin soll
20. „Hast du schon eine Internet-Adresse, unter der die Seite laufen soll? Oder soll ich dir zeigen, wie du sie zuerst nur für dich sichtbar machst?"
21. „Wie sollen Menschen dich von der Seite aus erreichen? Formular, Mailadresse, Telefonnummer, Terminlink?"

Am Ende: Fasse den Steckbrief in zehn Zeilen zusammen, lies sie ihr vor und frag: „Habe ich dich richtig verstanden?" Erst danach baust du.

---

## Teil 2 — Der Baukasten

Bevor du baust, lässt du sie aussuchen, was ihre Seite können soll. Öffne dafür `bausteine.html` aus diesem Skill-Ordner in ihrem Browser. Das ist eine Musterseite: Sie scrollt einmal durch und sieht alle Effekte in Bewegung, statt sich etwas vorstellen zu müssen.

Sag ihr dazu: „Scroll einmal in Ruhe durch. Jeder Abschnitt ist ein Baustein, den du haben kannst oder eben nicht. Sag mir danach einfach die Nummern, die dir gefallen."

Die acht Bausteine, in ihrer Sprache erklärt:

| Nr | Baustein | Wofür er gut ist |
|---|---|---|
| 1 | Fragen zum Aufklappen | Ablauf, Kosten, Voraussetzungen. Die Seite bleibt kurz, wer mehr wissen will, klappt auf. |
| 2 | Bildkarten, die sich umdrehen | Vorne ein Bild und ein Wort, hinten die Erklärung. Gut für Angebote oder Ablaufschritte. |
| 3 | Ein Bild, in das man hineinfährt | Zoomt beim Scrollen langsam heran. Ruhig und filmisch, gut für Räume oder Stadt. |
| 4 | Der Vorhang | Ein Bild teilt sich in der Mitte und gibt einen Satz frei. Der stärkste Effekt, genau einmal einsetzen. |
| 5 | Der Ablauf als Zeitstrahl | Schritt für Schritt, die Linie füllt sich beim Scrollen. Nimmt die Angst vor dem ersten Schritt. |
| 6 | Laufband mit Zahlen | Jahre, Fälle, Vorträge, Mitgliedschaften. Läuft langsam durch. |
| 7 | Stimmen, die weiterblättern | Mehrere Stimmen an einer Stelle statt einer langen Liste. |
| 8 | Sätze, die einzeln kommen | Ihre Haltung, Satz für Satz auf dem Bildschirm. Wirkt stark, braucht echte Sätze. |

Dazu die Fragen, die du ihr stellst:
1. „Welche Nummern gefallen dir? Nenn mir ruhig alle, wir sortieren gleich."
2. „Und bei welchen hast du sofort gedacht: das bin ich nicht?"
3. Zu jedem gewählten Baustein: „Was soll da drinstehen?" Frag nach Inhalt, bevor du ihn einbaust. Ein Zeitstrahl ohne echte Schritte ist eine leere Geste.
4. Wenn sie mehr als vier wählt: „Deine Seite wirkt stärker, wenn nicht alles gleichzeitig passiert. Welche drei sind dir am wichtigsten?" Empfiehl, den Rest später zu ergänzen, wenn sie ihn vermisst.

**Deine Leitplanken beim Zusammenstellen:**
- **Der Vorhang und die einzelnen Sätze sind Höhepunkte.** Höchstens einer davon pro Seite, sonst heben sie sich gegenseitig auf.
- **Bewegte Bausteine gehören auseinander.** Zwischen zwei Effekten steht ein ruhiger Abschnitt mit Text, sonst wird die Seite unruhig.
- **Kein Baustein ohne Inhalt.** Wenn sie zum Laufband keine Zahlen hat, lass es weg und sag ihr das ehrlich, statt Platzhalter zu erfinden.
- **Der Bildöffner aus der Grundseite bleibt immer.** Er ist der erste Effekt, den ihre Leserin sieht.
- Wenn sie unsicher ist, empfiehl diese ruhige Grundausstattung: Fragen zum Aufklappen, Stimmen, Zeitstrahl. Damit steht eine seriöse Seite, und Höhepunkte kann sie jederzeit nachlegen.

**Beim Einbauen:** Kopiere aus `bausteine.html` den gewählten Abschnitt mitsamt seinem CSS (jeweils zwischen den BAUSTEIN-Kommentaren) und seinem Teil des Skripts in ihre Seite. Die Farben ziehen automatisch mit, weil alle Bausteine dieselben Farbvariablen benutzen wie ihre Seite. Ersetze jeden Mustertext durch ihre Sätze.

**Was nicht geht, und das sagst du offen:** Auf Maikes Seite gibt es eine Bildfolge aus 160 Einzelbildern, die beim Scrollen wie ein Film abläuft. Das braucht eine Videoaufnahme und viel Nacharbeit und ist in ihrer einen Datei nicht sinnvoll nachzubauen. Ihr Bildöffner und Baustein 3 kommen dem sehr nahe. Wenn sie es unbedingt will, ist das ein Thema für einen Call mit Maike, nicht für heute.

## Teil 3 — Bauen

Bau **eine einzige Datei** `meine-seite.html`. Alles steckt darin: Aufbau, Farben, Bewegung. Nur ihre Bilder liegen daneben im Ordner `bilder/`.

Nutze die Vorlage `vorlage.html` aus diesem Skill-Ordner als Gerüst und ersetze darin:
- die Farbwerte oben in der Datei durch ihre Farben,
- alle Platzhalter-Texte durch ihre Sätze aus dem Steckbrief,
- den Bildnamen durch ihr Foto.

Der Aufbau der Seite, von oben nach unten:
1. **Kopfzeile**, die beim Scrollen mitwandert und milchig wird.
2. **Der Öffner:** ihr Satz aus Frage 7, groß, darunter ein Knopf mit ihrem Wunsch-Schritt aus Frage 3.
3. **Ihr Bild, das beim Scrollen aufgeht:** Das Foto beginnt schmal und ruhig und wächst beim Scrollen langsam auf, während sich ein kurzer Satz darüber legt. Das ist der Moment, in dem die Seite lebendig wird.
4. **Wofür sie da ist:** drei Glas-Karten mit den drei Dingen aus Frage 10.
5. **Für wen das ist:** die Lage aus Frage 2 in zwei, drei warmen Sätzen, damit die Leserin sich erkennt.
6. **Stimmen:** die Zitate aus Frage 12.
7. **Häufige Fragen:** die Fragen aus Frage 5 und die Bremsen aus Frage 6, ehrlich beantwortet.
8. **Der Abschluss:** derselbe Knopf wie oben, dazu ihre Erreichbarkeit aus Frage 21.
9. **Fußzeile** mit Impressum und Datenschutz.

Diese Bewegungen sind eingebaut und bleiben erhalten:
- Abschnitte, die beim Hochscrollen sanft auftauchen.
- Das Bild, das beim Scrollen langsam größer wird.
- Milchige Glas-Karten mit weichem Schatten.
- Ein Knopf mit warmem Metall-Verlauf, über den beim Darüberfahren ein Glanz wandert.
- Alles funktioniert auch auf dem Handy und respektiert die Einstellung „Bewegung reduzieren".

**Regeln beim Bauen:**
- **Null Anfragen an Dritte, ohne Ausnahme.** Keine Schriften von Google-Servern (deutsche Gerichte haben das ohne Einwilligung als DSGVO-Verstoß gewertet), keine Zähler, keine Tracker, keine eingebetteten Videos, Karten oder Kalender von fremden Seiten. Die Vorlage nutzt Schriften, die auf dem Gerät der Leserin vorhanden sind. So braucht die Seite kein Cookie-Banner, und genau das ist bei ihr ein Verkaufsargument. Terminkalender und Videos werden verlinkt statt eingebettet, dann passiert der Datenverkehr erst beim Anbieter, nicht auf ihrer Seite.
- Impressum und Datenschutzerklärung aus Block E sind Teil der Datei und bleiben es. Bau sie niemals aus, auch nicht „vorläufig".
- Echte Umlaute, ganze Sätze, ihre Sprache. Keine Werbefloskeln.
- Wenn sie kein Foto hat, bau die Seite mit einer ruhigen Farbfläche und sag ihr, dass ein Foto später einfach ergänzt werden kann.

## Teil 4 — Zeigen

Öffne die fertige Seite direkt in ihrem Browser, damit sie sie sofort sieht. Sag ihr dazu: „Das liegt nur bei dir auf dem Rechner, noch sieht das niemand außer dir."

Dann geh mit ihr durch:
- „Fühlt sich der erste Satz nach dir an?"
- „Stolperst du irgendwo?"
- „Was fehlt dir, wenn du es mit den Augen deiner Mandantin liest?"

Ändere so lange, bis sie zufrieden ist. Jede Änderung ist eine Frage von Sekunden, sag ihr das ruhig, damit sie sich traut, ehrlich zu sein.

## Teil 5 — Ihre eigenen Bilder

Ihre Bilder liegen in `03 Bereiche/Meine Seite/bilder/`. Sie legt eine Datei dort hinein und sagt dir in einem normalen Satz, wofür sie ist („nimm das für das große Bild oben"). Alles Weitere machst du.

Beim Einbinden:
1. **Nachschauen, was da ist.** Lies den Ordner, statt sie nach Dateinamen zu fragen. Wenn mehrere Bilder infrage kommen, beschreib sie ihr in Worten („das helle Querformat am Fenster") und lass sie wählen.
2. **Fürs Netz vorbereiten.** Fotos direkt aus der Kamera oder vom Handy sind für eine Seite viel zu groß. Rechne sie auf ungefähr 2000 Punkte an der langen Seite herunter und speichere sie platzsparend, damit die Seite auch mobil schnell lädt. Sag ihr in einem Satz, dass du das gemacht hast, und behalte ihr Original unangetastet.
3. **Einbauen und zeigen.** Trag das Bild in ihre Seite ein, schreib einen sinnvollen Alternativtext dazu (was auf dem Bild zu sehen ist, für Menschen, die die Seite vorgelesen bekommen) und öffne die Seite.
4. **Ausschnitt nachjustieren.** Wenn sie sagt „zeig mehr von links" oder „mein Kopf ist angeschnitten", ändere die Bildausrichtung, nicht das Bild selbst.

**Was du ihr zum großen Bild sagen darfst:** Ein ruhiges Motiv mit Fläche wirkt am besten, weil sich beim Scrollen ein Satz darüberlegt. Querformat passt dort meistens besser als Hochformat.

Wenn Bilder fehlen, bau die Seite mit einer ruhigen Farbfläche und sag ihr, dass ein Foto jederzeit nachkommen kann.

## Teil 6 — Später ändern

**Vor jeder Änderung eine Sicherheitskopie.** Leg die bisherige Fassung als `03 Bereiche/Meine Seite/_fassungen/meine-seite JJJJ-MM-TT-HHMM.html` ab, bevor du etwas anfasst. Behalte die letzten zehn Fassungen, ältere kannst du aufräumen. Nur so stimmt der Satz, den sie kennt: „Mach das wieder rückgängig."

Wenn sie mit „ändere auf meiner Seite …" kommt:
1. Lies den Steckbrief, damit die Seite in ihrer Sprache bleibt.
2. Sicherheitskopie anlegen.
3. Änder nur das Genannte, lass den Rest unangetastet.
4. Zeig ihr das Ergebnis im Browser.
5. Halte im Steckbrief fest, was sich geändert hat und wann.
6. **Wenn ihre Seite schon öffentlich ist:** erinnere sie in einem Satz daran, dass die Änderung erst nach dem nächsten Hochladen draußen sichtbar ist, und biete an, die Datei fertigzumachen.

Bei „mach das wieder rückgängig" nimmst du die letzte Fassung aus `_fassungen/` und zeigst ihr das Ergebnis.

## Teil 7 — Ins Netz

Frag zuerst: „Willst du die Seite jetzt schon öffentlich haben, oder erst noch jemanden drüberschauen lassen?" **Nichts geht online, ohne dass sie es ausdrücklich sagt.** Lade selbst nichts hoch und veröffentliche nichts eigenmächtig, auch dann nicht, wenn es technisch möglich wäre. Deine Aufgabe ist es, alles vorzubereiten und sie zu begleiten.

Vor jedem Weg machst du ihre Seite fertig:
- Die Datei heißt zum Hochladen **`index.html`**, sonst erkennt sie kein Anbieter als Startseite.
- Der Ordner `bilder` gehört immer mit, sonst bleiben die Rahmen leer.
- Leg beides zusammen in einen Ordner `03 Bereiche/Meine Seite/zum-hochladen/` und sag ihr, dass genau dieser Ordner hochgeladen wird.

Dann die drei Wege, empfiehl den ersten zum Ausprobieren:

1. **Zum Ausprobieren:** Sie zieht den Ordner auf eine Stelle, die Dateien direkt annimmt (zum Beispiel Netlify Drop), und bekommt sofort eine Adresse zum Zeigen. Kein Konto nötig.
2. **Auf ihre eigene Adresse (IONOS und ähnliche Anbieter):** Sie meldet sich bei ihrem Anbieter an, öffnet dort die Dateiverwaltung (bei IONOS meistens „Webspace Explorer", anderswo „Dateimanager") und lädt `index.html` und den Ordner `bilder` in den Ordner ihrer Startseite. Die genauen Bezeichnungen ändern sich mit der Zeit, lass sie nach dem Menüpunkt mit „Datei" oder „Webspace" suchen und rate nicht.
   **Wichtig:** Wenn dort schon eine Seite von ihr liegt, wird nichts überschrieben. Frag sie, ob die neue Seite ihre Startseite werden soll oder unter einem Zusatz laufen soll, und leg sie im zweiten Fall in einen eigenen Unterordner.
3. **Weitergeben:** Sie schickt den Ordner an die Stelle, die ihre Seite betreut, mit einem Satz. Formulier ihr den Satz, sie muss nichts erklären.

Bevor sie öffentlich geht, sind zwei Dinge Pflicht: Sie hat Impressum und Datenschutzerklärung gelesen und ausdrücklich freigegeben (erst dann nimmst du den Entwurf-Hinweis heraus), und auf der Seite steht nichts Vertrauliches. Ohne beides gehst du den Weg ins Netz nicht weiter, sondern sagst ihr freundlich, was noch fehlt.

## Teil 8 — Der Testdurchlauf

Sobald die Seite erreichbar ist, geh diese Liste **mit ihr gemeinsam** durch, Punkt für Punkt, und hak ab. Was nicht stimmt, änderst du sofort und prüfst noch einmal. Halte das Ergebnis in `03 Bereiche/Meine Seite/Testdurchlauf.md` fest.

1. **Die Seite öffnet sich** unter der Adresse, keine leere Seite, keine Fehlermeldung.
2. **Das große Bild ist da.** Leerer Rahmen bedeutet fast immer: der Ordner `bilder` fehlt oben.
3. **Das Bild geht beim Scrollen auf** und der Satz darüber blendet ein.
4. **Die Knöpfe führen wirklich irgendwohin.** Klick oben und unten und schau, ob sich ihre Mail, ihr Kalender oder ihr Formular öffnet. Prüf die Mailadresse auf Tippfehler.
5. **Impressum und Datenschutz öffnen sich.**
6. **Auf dem Handy.** Lass sie die Seite auf ihrem Telefon aufrufen. Nichts darf seitlich herausragen, alles muss ohne Zoomen lesbar sein.
7. **Der Fünf-Sekunden-Blick.** Lass jemanden fünf Sekunden schauen und dann sagen, was sie beruflich macht und was man hier tun soll. Passt die Antwort nicht, liegt es am ersten Satz, nicht am Rest.
8. **Einmal laut lesen.** Alles, worüber sie stolpert, wird geändert.
9. **Ihre Angaben stimmen**, Zeichen für Zeichen: Name, Titel, Mail, Telefon.
10. **Nichts Vertrauliches steht drauf.** Keine Mandantinnen-Namen, keine Fälle, nichts Angedeutetes.

Zum Schluss sagst du ihr, was geprüft ist, und feierst kurz mit ihr. Das ist der Moment, in dem ihre Seite wirklich steht.

## Teil 9 — Wenn etwas klemmt

Die vier üblichen Fälle, in dieser Reihenfolge prüfen:
- **Leerer Rahmen statt Bild:** Der Ordner `bilder` fehlt oben oder das Bild heißt anders als in der Seite eingetragen.
- **Änderung nicht sichtbar:** Die neue Datei wurde noch nicht hochgeladen, oder ihr Browser zeigt die gespeicherte alte Fassung. Lass sie einmal kräftig neu laden.
- **Unter ihrer Adresse kommt die alte Seite:** Die Datei liegt im falschen Ordner oder heißt nicht `index.html`.
- **Etwas versehentlich gelöscht:** Letzte Fassung aus `_fassungen/` zurückholen.

Rate nie. Wenn du es nicht sicher weißt, sag ihr das und geh es Schritt für Schritt mit ihr durch.
