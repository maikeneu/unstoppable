---
name: mein-abend-bericht
description: Baut der Nutzerin ihren täglichen Abend-Bericht als feste Routine, hält ihre Erfolge fest und ändert die Routine später. Aktiviere bei "bau mir meinen Abend-Bericht", "meinen Tagesabschluss", "mein Erfolgstagebuch", "meinen Abend-Bericht ändern".
user-invocable: true
---

# Dein Abend-Bericht

## Was dieser Skill macht

Er richtet ein, dass der Tag abends einen Abschluss bekommt: kurz zurückschauen, festhalten was gut lief, den nächsten Morgen vorbereiten. Und er sorgt dafür, dass daraus über die Monate ihr eigenes Erfolgsbuch wächst.

## Die wichtigste Regel

Abends ist Feierabend. Der Bericht darf niemals eine neue Aufgabenliste sein, die sie um halb neun noch unter Druck setzt. Er schaut zurück und macht ruhig. Wenn du unsicher bist, ob etwas in den Abend gehört: Es gehört in den Morgen.

Sprich warm und auf Deutsch, ohne Fachbegriffe. Sie beantwortet Fragen, du baust.

---

## Teil 1 — Das Interview

Immer nur eine Frage, notiert in `03 Bereiche/Meine Routinen/Mein Abend-Bericht (Steckbrief).md`.

1. „Wann ist bei dir Feierabend? Und wann willst du den Bericht sehen: kurz vorher oder erst danach?"
2. „Woran merkst du abends, dass ein Tag gut war?"
3. „Was willst du festhalten, damit es dir in einem halben Jahr noch etwas sagt?"
4. „Passiert es dir, dass du abends denkst, du hättest nichts geschafft, obwohl der Tag voll war?" (Wenn ja: Der Bericht soll genau dagegen arbeiten und ihr zeigen, was tatsächlich passiert ist.)
5. „Willst du abends schon wissen, was morgen ansteht, oder willst du das bewusst nicht mehr sehen?"
6. „Soll dich dein System abends etwas fragen, oder soll es einfach nur berichten?"
7. „Gibt es etwas, das abends auf keinen Fall vorkommen soll?"
8. „Soll der Ton eher nüchtern oder eher zugewandt sein?"

Fass zusammen und frag: „Habe ich dich richtig verstanden?"

---

## Teil 2 — Die Routine bauen

1. **Arbeitsanweisung anlegen** in `~/.claude/scheduled-tasks/mein-abend-bericht/SKILL.md`, mit `name`, `description` und der vollständigen Anweisung aus ihren Antworten.

2. **Feste Plätze für das Ergebnis:**
   - Der Bericht: `03 Bereiche/Meine Routinen/Berichte/JJJJ-MM-TT Abend.md`
   - Ihre Erfolge: `03 Bereiche/Meine Routinen/Mein Erfolgsbuch.md`, unten angehängt, mit Datum, niemals überschrieben.

3. **Aufbau des Berichts** (nur die Teile, die sie wollte):
   - was heute tatsächlich entstanden ist (schau in ihren Ordnern nach, was sich geändert hat, statt zu raten),
   - was von heute offen blieb, ohne Vorwurf, damit es morgen früh im Briefing auftaucht,
   - ein bis drei Sätze, die sie später gern liest: was heute gut lief,
   - falls gewünscht: ein Blick auf morgen, höchstens drei Zeilen.

4. **Ins Erfolgsbuch schreiben.** Häng jeden Abend einen kurzen Eintrag mit Datum an ihr Erfolgsbuch an. Schreib in ihrer Sprache und übertreib nicht: kleine echte Sätze sind mehr wert als große leere. Schreib niemals etwas dazu, das nicht passiert ist.

5. **Zeitplan setzen** auf die Uhrzeit aus Frage 1, mit dem Werkzeug für geplante Aufgaben.

6. **Sofort probelaufen lassen** und ihr das Ergebnis zeigen. Frag:
   - „Fühlt sich das nach einem guten Abschluss an?"
   - „Ist irgendwas dabei, das dich abends noch aufregen würde?"
   Ändere sofort und lauf noch einmal.

7. **Den Bogen zeigen.** Sag ihr am Ende: „In vier Wochen kannst du dein Erfolgsbuch von oben nach unten lesen. Das ist dann der Beweis, den du dir gerade selbst nicht glaubst."

---

## Teil 3 — Später ändern

Wie beim Morgen-Briefing: Steckbrief lesen, Arbeitsanweisung ändern, einmal probelaufen, Änderung im Steckbrief festhalten.

Wenn sie sagt, der Abend-Bericht stört sie: Frag, ob er zu spät kommt, zu lang ist oder zu sehr nach Arbeit klingt, und ändere genau das. Im Zweifel lieber kürzen als abschaffen.
