---
name: mein-morgen-briefing
description: Baut der Nutzerin ihr tägliches Morgen-Briefing als feste Routine und ändert es später. Aktiviere bei "bau mir mein Morgen-Briefing", "mein Briefing ändern", "ich will morgens auch noch X wissen", "mein Morgen-Briefing läuft nicht", "zeig mir mein Briefing".
user-invocable: true
---

# Dein Morgen-Briefing

## Was dieser Skill macht

Er richtet ein, dass sich das System jeden Morgen von selbst meldet, mit genau dem, was diese eine Frau morgens braucht. Und er ändert das Briefing später, wenn sich ihr Alltag ändert.

## Die wichtigste Regel

Sie beantwortet Fragen, du baust. Sprich warm und auf Deutsch, ohne Fachbegriffe. Sag „deine Routine" und „dein Briefing", nicht „Task", nicht „Cron", nicht „Skript".

Ein Briefing, das zu lang ist, wird nach vier Tagen nicht mehr gelesen. Bau lieber zu kurz und ergänze später.

---

## Teil 1 — Das Interview

Stell immer nur eine Frage, warte ab, hak nach. Notiere die Antworten in `03 Bereiche/Meine Routinen/Mein Morgen-Briefing (Steckbrief).md`.

**Der Rahmen**
1. „Wie sieht dein Morgen normalerweise aus? Erzähl mir einfach, wie die ersten zwei Stunden ablaufen."
2. „Um welche Uhrzeit sitzt du verlässlich am Rechner? Nicht die Wunschzeit, die echte."
3. „Liest du lieber am Rechner oder am Handy?"
4. „Wie lang darf dein Briefing sein? Fünf Zeilen, eine halbe Seite, eine ganze Seite?"

**Der Inhalt**
5. „Was willst du morgens als Erstes wissen?"
6. „Was schaust du morgens jeden Tag selbst nach? Kalender, Postfach, Nachrichten, irgendetwas Fachliches?"
7. „Was davon nervt dich am meisten?"
8. „Gibt es etwas, das dir regelmäßig durchrutscht und dich dann ärgert?"
9. „Willst du morgens auch einen Satz, der dich in Schwung bringt, oder ist dir das zu viel?"
10. „Soll dein Briefing dir einen Vorschlag machen, worauf du dich heute konzentrierst? Oder entscheidest du das lieber selbst?"
11. „Gibt es etwas, das morgens auf keinen Fall vorkommen soll?"

**Der Ton**
12. „Soll dein Briefing sachlich sein oder warm?"
13. „Soll dein Name darin vorkommen?"

Fass am Ende zusammen, was du gebaut hättest, lies es ihr vor und frag: „Habe ich dich richtig verstanden?"

---

## Teil 2 — Die Routine bauen

1. **Arbeitsanweisung anlegen.** Leg den Ordner `~/.claude/scheduled-tasks/mein-morgen-briefing/` an und schreib dort eine `SKILL.md`. Sie enthält im Kopf `name` und `description` und danach die vollständige Arbeitsanweisung: was gelesen wird, was geschrieben wird, in welchem Ton, wie lang. Schreib die Anweisung so, dass sie auch in vier Wochen ohne dieses Gespräch verständlich ist.

2. **Das Ergebnis hat einen festen Platz.** Das Briefing wird geschrieben nach:
   `03 Bereiche/Meine Routinen/Briefings/JJJJ-MM-TT Morgen.md`
   Zusätzlich aktualisierst du `03 Bereiche/Meine Routinen/Heute.md` als immer gleiche Datei, die sie sich auf den Schreibtisch legen kann und in der immer der aktuelle Stand steht.

3. **Aufbau des Briefings** (nur die Teile, die sie wirklich wollte):
   - eine Zeile Begrüßung mit Datum und Wochentag,
   - ihre Termine heute,
   - was aus gestern offen ist,
   - was ihre Rechercheure über Nacht gefunden haben (siehe Tag 3 der Challenge), jeweils in wenigen Zeilen,
   - ein Vorschlag für ihren Fokus heute, klar als Vorschlag formuliert,
   - falls gewünscht: ein Satz zum Mitnehmen.

4. **Zeitplan setzen.** Leg die Routine mit dem Werkzeug für geplante Aufgaben auf ihre echte Uhrzeit aus Frage 2, ungefähr zwanzig Minuten bevor sie sitzt. Erklär ihr in einem Satz, dass die Routine nur läuft, wenn der Rechner wach ist und ihre App geöffnet ist, und dass ein verpasster Morgen kein Problem ist.

5. **Nachholen einbauen.** Schreib in die Arbeitsanweisung: Wenn das Briefing von heute noch nicht existiert und es später am Tag gestartet wird, wird es einfach jetzt erstellt, ohne Klage.

6. **Sofort probelaufen lassen.** Starte das Briefing einmal von Hand und zeig ihr das Ergebnis. Das ist der wichtigste Moment: Sie sieht heute, was sie morgen bekommt. Frag danach:
   - „Was davon würdest du wirklich lesen?"
   - „Was ist zu viel?"
   - „Was fehlt?"
   Ändere sofort und lauf noch einmal, bis sie sagt: das würde ich lesen.

---

## Teil 3 — Später ändern

Wenn sie sagt „ich will morgens auch noch …" oder „das lese ich nie":
1. Lies den Steckbrief.
2. Änder die Arbeitsanweisung, nicht das alte Briefing.
3. Lass einmal probelaufen und zeig ihr das Ergebnis.
4. Halte im Steckbrief fest, was sich wann geändert hat.

Frag sie einmal im Monat unaufgefordert: „Liest du dein Briefing noch? Was würdest du streichen?" Eine Routine, die nicht gelesen wird, wird gekürzt oder abgeschaltet. Das ist kein Rückschritt, das ist Pflege.

## Wenn morgens nichts kam

Sag ihr ruhig die drei üblichen Gründe, in dieser Reihenfolge:
1. Der Rechner war aus oder im Schlaf.
2. Die App war geschlossen.
3. Sonst: einmal von Hand starten, dann prüfst du die Arbeitsanweisung.

Nichts davon ist kaputt und nichts davon geht verloren.
