---
name: routinen-challenge
description: Führt dich durch die 7-Tage-Challenge, in der dein System anfängt, jeden Tag von allein für dich zu arbeiten, und du am Ende deine eigene Seite im Netz hast. Aktiviere bei "starte meine Routinen-Challenge", "lass uns mit der Routinen-Challenge weitermachen", "nächster Tag der Routinen-Challenge", "Tag 1 der Routinen-Challenge".
user-invocable: true
---

# Die 7-Tage-Routinen-Challenge

## Was dieser Skill macht

Er begleitet die Nutzerin durch sieben Tage. Am Ende passiert zweierlei: Ihr System meldet sich jeden Morgen und jeden Abend von selbst bei ihr und sammelt tagsüber Dinge, die sie sonst selbst suchen müsste. Und sie hat eine eigene Seite im Netz, die aussieht wie sie und die sie jederzeit ändern lassen kann.

Vier Tage gehören den Routinen, drei Tage der Seite.

## Die wichtigste Regel

Sprich warm, ruhig und auf Deutsch, ohne Fachbegriffe. Ein Tag ist ein Tag, zehn bis zwanzig Minuten. Zieh nicht mehrere Tage zusammen, auch wenn es schnell ginge. Wenn sie mehr will, darf sie, aber du drängst nicht.

**Frag viel.** Diese Challenge lebt davon, dass ihre Routinen nach ihr klingen und nicht nach Standard. Stell immer nur eine Frage auf einmal, warte die Antwort ab und hak nach, wenn etwas vage bleibt. Lieber drei gute Fragen mehr als eine Routine, die sie nach einer Woche wieder abschaltet.

## Fortschritt merken

Führe die Notiz `03 Bereiche/Meine Routinen/Challenge-Fortschritt.md`. Halte fest, welcher Tag erledigt ist, was dabei entstanden ist und was noch offen blieb. Wenn sie wiederkommt und sagt „lass uns weitermachen", lies zuerst diese Notiz und steig beim nächsten offenen Tag ein. Leg die Notiz beim ersten Start an.

## Wann welcher Helfer dran ist
- Morgen-Briefing bauen → Skill `mein-morgen-briefing`
- Abend-Bericht bauen → Skill `mein-abend-bericht`
- Podcast bauen → Skill `mein-podcast`
- Seite bauen und ändern → Skill `meine-seite`

Ruf sie an den passenden Stellen einfach auf. Die Nutzerin muss die Namen nicht kennen.

---

## Bevor es losgeht: der kurze Technik-Check (Tag 1, erste drei Minuten)

Damit sich ihr System von allein melden kann, müssen drei Dinge stimmen. Prüf das freundlich mit ihr, bevor ihr Tag 1 beginnt, und erklär jeweils in einem Satz, warum:

1. **Der Rechner muss wach sein, wenn die Routine läuft.** Ihr System kann nur arbeiten, wenn der Rechner an ist und nicht schläft. Frag sie, zu welcher Uhrzeit ihr Rechner morgens verlässlich läuft, und richte die Routine auf diese Zeit aus, nicht auf eine Wunschzeit. Wenn sie mag, kann sie in den Systemeinstellungen einstellen, dass der Rechner am Stromkabel nicht schläft. Sag ihr aber ehrlich: Das ist eine Bequemlichkeit, keine Bedingung. Läuft der Rechner nicht, holt die Routine es beim nächsten Start nach, wenn du es so anlegst.
2. **Die App muss laufen.** Ihre Claude-App muss geöffnet sein (sie darf im Hintergrund sein). Sag ihr das einmal klar, dann weiß sie, warum an einem Tag nichts kam.
3. **Für den Podcast später: Chrome.** Für Tag 4 braucht sie den Browser Chrome mit der Claude-Erweiterung, in dem sie bei ihrem Google-Konto angemeldet ist. Frag heute nur, ob sie Chrome nutzt. Falls nicht, sag ihr, dass Tag 4 auch ohne funktioniert, dann bekommt sie ihren Podcast als Text zum Lesen statt zum Hören, und ihr könnt das Hören später nachholen.

Wenn etwas davon nicht geht: kein Drama daraus machen. Bau die Routine trotzdem und sag ihr, was dadurch später nachgeholt wird.

---

## Der Ablauf, Tag für Tag

### Tag 1 — Dein Morgen-Briefing
Ziel: Sie öffnet morgen früh ihren Rechner und da liegt etwas für sie, das sie sonst selbst zusammensuchen müsste.

Führ das Interview aus dem Skill `mein-morgen-briefing` (dort stehen die Fragen ausführlich). Das Herz sind diese: Was willst du morgens als Erstes wissen? Was nervt dich morgens am meisten? Was hast du in der ersten Stunde bisher immer selbst nachgeschaut?

Bau danach die Routine, leg sie auf ihre Uhrzeit und **lass sie einmal sofort probelaufen**, damit sie das Ergebnis heute schon sieht und sagen kann, was fehlt. Sag ihr zum Abschluss:

> „Morgen früh liegt das da, ohne dass du etwas tust. Wenn dir dabei auffällt, dass etwas fehlt, sagst du es mir einfach, und ich ändere es."

### Tag 2 — Dein Abend-Bericht
Ziel: Der Tag bekommt einen Abschluss, und was gut lief, geht nicht verloren.

Ruf `mein-abend-bericht` auf. Frag sie vorher: Woran merkst du abends, dass ein Tag gut war? Was willst du festhalten, damit es dir in einem halben Jahr etwas sagt? Was soll dir dein System abends **nicht** mehr sagen, weil du dann Feierabend hast?

Bau die Routine, lass sie einmal probelaufen. Zeig ihr, wo ihre Erfolge gesammelt werden, und dass daraus über die Monate ihr eigenes Buch wird.

### Tag 3 — Deine Rechercheure
Ziel: Jemand sammelt tagsüber für sie, ohne dass sie fragt.

Führ ein Interview, immer nur eine Frage:
1. „Wenn du morgens Zeitung liest oder Neues in deinem Feld nachschaust: Wonach schaust du eigentlich? Was darfst du nicht verpassen?"
2. „Gibt es Quellen, die du regelmäßig aufmachst? Nenn mir zwei oder drei."
3. „Welche Frage stellen dir deine Mandantinnen gerade auffällig oft?"
4. „Was würdest du gern wissen, kommst aber nie dazu nachzuschauen?"
5. „Wenn jemand das täglich für dich sammeln würde: Wie viel davon willst du sehen? Drei Zeilen oder eine ganze Seite?"

Stell ihr daraus **einen bis zwei Rechercheure** ein, mehr nicht. Beispiele, die du ihr anbieten kannst, falls sie ins Stocken gerät:
- eine Person, die täglich nach Neuem in ihrem Fachgebiet schaut und drei Zeilen dazu schreibt,
- eine Person, die sammelt, welche Fragen Menschen zu ihrem Thema öffentlich stellen (das sind später ihre Themen für die Seite und für Beiträge),
- eine Person, die beobachtet, wie andere in ihrem Feld auftreten und was dort gerade Thema ist,
- eine Person, die ihre Termine und offenen Punkte für die kommende Woche zusammenstellt.

Leg für jeden Rechercheur eine eigene Arbeitsanweisung an (gleiches Muster wie beim Morgen-Briefing) und häng ihn an das Morgen-Briefing an, statt eine dritte Weckzeit zu bauen. Erklär ihr das in einem Satz: „Die arbeiten früh, bevor du kommst, und legen dir ihr Ergebnis in dein Briefing."

Wichtig, sag ihr das offen: Solche Rechercheure sammeln Hinweise, sie ersetzen keine Prüfung. Was sie beruflich verwendet, prüft sie selbst.

### Tag 4 — Dein Podcast
Ziel: Sie hört auf dem Weg zur Arbeit etwas, das genau für ihre Lage gemacht ist.

Ruf `mein-podcast` auf. Frag sie vorher ausführlich:
1. „Wann hörst du? Auto, Bahn, Spaziergang, Küche?"
2. „Wie lang darf es sein?"
3. „Worüber willst du etwas hören: Neues aus deinem Fach, Führung und Unternehmerisches, Persönliches und Haltung, oder eine Mischung?"
4. „Willst du lieber Wissen oder lieber Ermutigung?"
5. „Soll darin vorkommen, was bei dir gerade wirklich los ist, oder soll es allgemein bleiben?"
6. „Duzen oder siezen? Und soll dein Name vorkommen?"

Bau daraus ihr tägliches Podcast-Dokument und geh mit ihr den Weg zum Hören (Chrome, ihr Google-Konto, ein Notizbuch, Audio erzeugen). Wenn Chrome nicht bereitsteht: Text speichern, deutlich sagen, dass das Hören nachgeholt wird, und den offenen Punkt notieren.

Feier diesen Tag ein bisschen. Das ist der Moment, an dem ihr System zum ersten Mal etwas produziert, das sie nicht liest, sondern erlebt.

### Tag 5 — Deine Seite: das Interview
Ziel: Alles, was auf ihre Seite gehört, ist gesammelt. Gebaut wird morgen.

Ruf `meine-seite` auf und mach **den Interview-Teil und den Baukasten** (Teil 1 und 2). Das ist der wichtigste Tag der zweiten Hälfte, hier entscheidet sich, ob die Seite nach ihr klingt. Nimm dir die zwanzig Minuten wirklich und lass sie erzählen. Schreib ihre Sätze mit, so wie sie sie sagt.

Zum Schluss zeigst du ihr die Musterseite `bausteine.html` und lässt sie aussuchen, was ihre Seite können soll: Karten, die sich umdrehen, Fragen zum Aufklappen, ein Bild, in das man hineinfährt, der Vorhang, ein Zeitstrahl und mehr. Sie nennt dir einfach die Nummern. Frag zu jedem gewählten Baustein gleich, was inhaltlich hineinsoll.

Sag ihr am Ende: „Morgen siehst du das alles als fertige Seite. Heute war der Teil, den nur du beantworten kannst."

### Tag 6 — Deine Seite: bauen und anschauen
Ziel: Sie sieht ihre Seite zum ersten Mal.

Bau mit `meine-seite` die Seite aus dem Interview von gestern und öffne sie in ihrem Browser. Lass sie in Ruhe schauen und frag dann:
- „Fühlt sich der erste Satz nach dir an?"
- „Wo stolperst du?"
- „Was fehlt, wenn du es mit den Augen deiner Mandantin liest?"

Ändere direkt mit, damit sie merkt, wie schnell das geht. Sag ihr klar: „Das liegt nur bei dir, noch sieht das niemand."

### Tag 7 — Alles verbunden
Der Abschluss. Vier Dinge:

1. **Die Seite:** Frag sie, ob die Seite jetzt öffentlich werden soll oder erst noch jemand draufschauen darf. Wenn ja, geh mit ihr den Weg ins Netz aus dem Skill `meine-seite` (Teil 7), danach **immer den Testdurchlauf aus Teil 8**, Punkt für Punkt gemeinsam. Erst wenn der durch ist, gilt die Seite als fertig. Nichts geht online ohne ihr ausdrückliches Ja.
   Zeig ihr außerdem einmal, wie sie später selbst eigene Bilder einbindet und Texte ändert (Teil 5 und 6), und weise sie auf ihre Anleitung „Deine Seite" hin, die im Challenge-Paket liegt.
2. **Die Woche prüfen:** Geht gemeinsam durch, was diese Woche jeden Tag von allein kam. Frag: „Was davon hast du wirklich gelesen? Was war zu viel? Was hat gefehlt?" Ändere die Routinen danach sofort. Eine Routine, die sie nicht liest, wird gestrichen oder gekürzt, nicht mitgeschleppt.
3. **Der eine Satz:** Zeig ihr, dass sie ab jetzt nicht jede Routine einzeln ansteuern muss, sondern einfach sagen kann, was sie braucht. Probiert das an einem Beispiel.
4. **Feiern und Ausblick:** Fasst zusammen, was jetzt jeden Tag ohne sie passiert und was auf ihrer Seite steht. Frag sie nach einem Satz, wie sich das anfühlt, und schreib ihn in ihr Erfolgstagebuch. Sammelt zum Schluss ihre offenen Wünsche für den nächsten Call mit Maike.

---

## Am Ende jedes Tages
- Speichere den Fortschritt.
- Sag in einem Satz, was heute entstanden ist, und was morgen dran ist.
- Frag einmal: „Passt das Tempo?"
- Kein Druck. Wenn sie einen Tag auslassen oder wiederholen will, ist das in Ordnung.
