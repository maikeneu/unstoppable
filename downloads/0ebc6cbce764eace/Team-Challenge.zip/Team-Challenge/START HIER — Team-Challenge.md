# Deine 7-Tage-Team-Challenge

Schön, dass du hier bist. In diesem Ordner liegt alles, was du für deine Team-Challenge brauchst. Du musst nichts Technisches tun und du kannst nichts kaputt machen. Nichts hiervon überschreibt dein bestehendes System, es kommt nur etwas Neues dazu.

## Was drin ist

- **7-Tage-Mitarbeiter-Challenge.pdf** — dein Fahrplan für die Woche. Lies ihn in Ruhe, wann du magst.
- Zwei Ordner und eine kurze Notiz, die deine neuen Fähigkeiten enthalten. Die legt dein Assistent gleich für dich an die richtige Stelle.

## Der einfache Weg (empfohlen)

1. Leg diesen ganzen Ordner **„Team-Challenge"** in deine **Inbox** (deinen Handy-Posteingang oder den Ordner `01 Inbox` in deinem zweiten Gehirn).
2. Öffne deinen Assistenten und sag ihm diesen einen Satz:

> **„In meiner Inbox liegt die Team-Challenge. Richte sie bitte für mich ein, ohne etwas zu überschreiben."**

Dein Assistent macht dann alles Weitere: Er legt deine neuen Fähigkeiten an die richtige Stelle, richtet deine Personalabteilung ein und sagt dir Bescheid, wenn alles bereit ist.

3. Danach startest du die Challenge mit:

> **„Starte meine Mitarbeiter-Challenge."**

Das war's. Ab hier führt dich dein Assistent Tag für Tag.

---

## Anweisung an den Assistenten (bitte stehen lassen)

Du richtest der Nutzerin die Team-Challenge in ihrem bestehenden Vault ein. **Oberste Regel: nur hinzufügen, niemals überschreiben oder löschen.** Sprich warm und auf Deutsch, ohne Fachbegriffe. Geh so vor:

1. **Sicherheitskopie zuerst.** Lege eine Kopie ihrer `00 Kontext/Mein Team.md` als `00 Kontext/Mein Team (Backup vor Team-Challenge).md` an, bevor du sie anfasst. Wenn diese Datei bei ihr noch nicht existiert, überspring den Backup-Schritt.

2. **Die neuen Fähigkeiten anlegen.** Kopiere die vier Ordner aus `1 — Neue Faehigkeiten/` nach `.claude/skills/` in ihrem Vault:
   `mitarbeiter-challenge`, `neue-mitarbeiterin`, `mitarbeiter-fortbildung`, `mein-organigramm`.
   Prüfe vorher, ob es einen dieser Ordner schon gibt. Falls ja, überschreib ihn nicht, sondern sag es ihr und frag, wie sie vorgehen möchte.

3. **Die Personalabteilung anlegen.** Kopiere den Ordner `2 — Personalabteilung/` als `03 Bereiche/Personalabteilung/` in ihren Vault (mit `Über diesen Bereich.md`, `Organigramm.md`, `Personalakten/_Vorlage Personalakte.md`). Falls es `03 Bereiche/Personalabteilung/` schon gibt, nichts überschreiben, sondern nachfragen.

4. **Die Team-Liste ergänzen (nur ergänzen).** Öffne ihre bestehende `00 Kontext/Mein Team.md` und füge die Abschnitte aus `3 — Mein Team (diese Zeilen ergaenzen).md` hinzu: den Abschnitt „Meine Mitarbeiterinnen" (direkt nach „Meine Berater") und die vier neuen Zeilen unter „Meine Helfer und Routinen". Ersetze nichts von dem, was schon dort steht. Wenn ein Abschnitt schon existiert, häng nur die fehlenden Zeilen an.

5. **Aufräumen und Bescheid geben.** Wenn alles liegt, kannst du den eingelegten Ordner „Team-Challenge" aus der Inbox entfernen (die PDF darf sie behalten). Sag ihr dann in einem Satz, was du eingerichtet hast, und dass sie mit „Starte meine Mitarbeiter-Challenge" loslegen kann.

6. **Wichtig:** Die neuen Fähigkeiten werden erst wirksam, wenn die native App einmal neu gestartet wurde. Weise sie freundlich darauf hin, die App einmal zu schließen und wieder zu öffnen, bevor sie startet.

Falls dir etwas unklar ist oder eine Datei schon existiert: nicht raten, nicht überschreiben, sondern kurz nachfragen.
