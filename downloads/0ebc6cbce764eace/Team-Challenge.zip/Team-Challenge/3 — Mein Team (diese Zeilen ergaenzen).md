# Diese Zeilen in „Mein Team" ergänzen

> Für den Assistenten: Diese beiden Blöcke in die bestehende `00 Kontext/Mein Team.md` einfügen. **Nur ergänzen, nichts ersetzen.** Den ersten Block direkt nach dem Abschnitt „Meine Berater" einsetzen. Die vier Zeilen aus dem zweiten Block unten an den Abschnitt „Meine Helfer und Routinen" anhängen.

---

## Meine Mitarbeiterinnen

Mitarbeiterinnen erledigen eine wiederkehrende Aufgabe für mich, auf Zuruf. Jede hat einen Namen, ein Gesicht und eine Personalakte in meiner [[Über diesen Bereich|Personalabteilung]]. Mein Team im Bild: [[Organigramm]].

- _(Hier trägt deine rechte Hand jede Mitarbeiterin ein, die du einstellst: Name — Job — wie du sie rufst → Personalakte.)_

---

Und diese vier Zeilen unten an „Meine Helfer und Routinen" anhängen:

- **Neue Mitarbeiterin** — stellt jemanden für einen wiederkehrenden Job ein. Aufruf: „ich brauche eine neue Mitarbeiterin".
- **Fortbildung** — bildet eine Mitarbeiterin weiter. Aufruf: „schick \<Name\> auf Fortbildung".
- **Organigramm** — zeigt mein Team auf einen Blick. Aufruf: „zeig mir mein Organigramm".
- **Team-Challenge** — begleitet mich in 7 Tagen beim Aufbau meines Teams. Aufruf: „starte meine Mitarbeiter-Challenge".
