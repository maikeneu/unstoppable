---
tags: [personalakte, team]
mitarbeiter: <Name>
rolle: <Kurzrolle>
abteilung: <z. B. Mandantenkommunikation>
eingestellt: <JJJJ-MM-TT>
status: aktiv
ruf: "<So rufst du sie>"
---

# Personalakte — <Name>

> Diese Vorlage nicht verändern. Deine rechte Hand oder der Einstellungs-Helfer legt für jede neue Mitarbeiterin eine eigene Kopie an.

![[<Vorname>.png]]
<!-- Wenn noch kein Bild da ist, steht hier stattdessen ein Monogramm, z. B.: **LM** -->

## Steckbrief

- **Name:** <Name>
- **Rolle:** <Kurzrolle>
- **Abteilung:** <Bereich, den sie abdeckt>
- **Im Team seit:** <JJJJ-MM-TT>
- **So rufst du sie:** „<Beispielauftrag>"

## Aufgabengebiet

<Was sie zuverlässig für dich erledigt, in klaren Worten. Ein bis drei feste Jobs.>

## Lebenslauf & Qualifikationen

<Ihr Werdegang in warmen Worten: worauf ihr Können beruht, welche Vorgehensweise sie beherrscht, welche Regeln und welches Wissen sie mitbringt. So, dass man beim Lesen das Gefühl hat, eine echte Fachkraft vor sich zu haben.>

## Weiterbildungen

Hier wächst sie mit dir. Jede neue Fähigkeit wird eingetragen.

| Datum | Neue Fähigkeit | Was sie jetzt besser kann |
| --- | --- | --- |
| <JJJJ-MM-TT> | <—> | <—> |

## Zusammenarbeit

- **Beauftragt von:** deiner rechten Hand (oder direkt von dir)
- **Arbeitet zusammen mit:** <andere Mitarbeiterinnen oder Berater, falls relevant>
- **Übergibt an:** <wer das Ergebnis weiterverwendet, falls relevant>

## Portrait-Prompt (für ihr Bild)

Damit spätere Bilder genauso aussehen, ist hier der feste Bild-Text hinterlegt:

```
professional editorial portrait photograph, head and shoulders, person looking calmly toward camera, warm cream background (#FCFAF7), soft natural light with a gentle copper-warm (#C96B2C) glow from the side, muted earthy tones, subtle film grain, shallow depth of field, approachable and competent expression, high-end magazine style, no text, no logo — <hier die kurze Beschreibung des Menschen, die zu dieser Rolle passt>
```
