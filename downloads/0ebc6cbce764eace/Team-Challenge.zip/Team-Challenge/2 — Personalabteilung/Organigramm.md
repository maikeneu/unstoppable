---
tags: [team, organigramm]
status: aktiv
---

# Mein Organigramm

Dein Team auf einen Blick. Diese Übersicht pflegt deine rechte Hand für dich. Immer wenn jemand dazukommt, wird sie hier eingetragen.

> Sag jederzeit „zeig mir mein Organigramm", dann wird das Bild unten aktualisiert und dir erklärt.

```mermaid
%%{init: {'theme':'base','themeVariables':{'lineColor':'#CBB6A5','primaryTextColor':'#211B17','primaryBorderColor':'#E7DCCD'}}}%%
graph TD
    CHEF["👑 Du<br/>(die Chefin)"]:::chef
    RH["🤝 Deine rechte Hand<br/>(dein Name steht hier)"]:::rh

    CHEF --> RH

    RH --> BERATER["💡 Deine Berater<br/>(geben Rat auf Nachfrage)"]:::gruppe
    RH --> TEAM["⚙️ Deine Mitarbeiterinnen<br/>(erledigen Aufgaben auf Zuruf)"]:::gruppe

    %% --- BERATER (hier trägt deine rechte Hand jeden Berater ein) ---
    %% Beispiel:
    %% BERATER --> B1["Name — wofür"]:::person

    %% --- MITARBEITERINNEN (hier trägt deine rechte Hand jede Mitarbeiterin ein) ---
    %% Beispiel:
    %% TEAM --> M1["Name — Job"]:::person

    classDef chef fill:#C96B2C,stroke:#A85A2A,color:#FCFAF7;
    classDef rh fill:#E7DCCD,stroke:#C96B2C,color:#211B17;
    classDef gruppe fill:#F4F0EA,stroke:#CBB6A5,color:#7A6E60;
    classDef person fill:#FFFFFF,stroke:#E7DCCD,color:#211B17;
```

## Wer gehört zu meinem Team

### Meine rechte Hand
- _(Name deiner rechten Hand — sie koordiniert alle anderen.)_

### Meine Berater
- _(Wird eingetragen, sobald du einen Berater baust: Name — wofür — wie du ihn rufst.)_

### Meine Mitarbeiterinnen
- _(Wird eingetragen, sobald du jemanden einstellst: Name — Job — wie du sie rufst → [[Personalakte]].)_
