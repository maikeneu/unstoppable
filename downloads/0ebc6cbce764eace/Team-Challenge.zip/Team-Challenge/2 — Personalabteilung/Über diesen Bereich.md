---
tags: [bereich, team]
status: aktiv
---

# Deine Personalabteilung

Das hier ist der Ort, an dem dein Team wohnt. Nicht als Liste, sondern als richtige kleine Belegschaft, mit Gesichtern und Akten.

- **[[Organigramm]]** — dein Team auf einen Blick. Wer gehört dazu, wer macht was, wer arbeitet mit wem.
- **Personalakten/** — für jede Mitarbeiterin eine eigene Akte: Steckbrief, Bild, Werdegang, Weiterbildungen.
- **Stellenplan** — falls du die 7-Tage-Challenge gemacht hast, liegt hier deine Planung, wen du nach und nach einstellst.

## So wächst dein Team

- **Jemanden einstellen:** sag „ich brauche eine neue Mitarbeiterin". → Skill `neue-mitarbeiterin`
- **Jemanden weiterbilden:** sag „schick <Name> auf Fortbildung". → Skill `mitarbeiter-fortbildung`
- **Dein Team ansehen:** sag „zeig mir mein Organigramm". → Skill `mein-organigramm`

Der Unterschied, den du dir merken darfst:
- Ein **Berater** gibt dir Rat, wenn du ihn fragst („frag <Name>").
- Eine **Mitarbeiterin** erledigt eine Aufgabe für dich, auf Zuruf („<Name>, mach …").

Deine schnelle Übersicht über alle zusammen steht außerdem in [[Mein Team]] in deinem Kontext-Ordner.
