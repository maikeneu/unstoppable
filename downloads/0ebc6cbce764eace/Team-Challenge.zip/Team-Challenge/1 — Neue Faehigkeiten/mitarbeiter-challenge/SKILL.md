---
name: mitarbeiter-challenge
description: Führt dich durch die 7-Tage-Challenge, in der du dir Schritt für Schritt dein eigenes Team aus Mitarbeiterinnen aufbaust. Aktiviere bei "starte meine Mitarbeiter-Challenge", "lass uns mit der Challenge weitermachen", "Tag 1 der Challenge", "Starte mit Tag 1", "nächster Tag der Challenge", "Team-Challenge".
user-invocable: true
---

# Die 7-Tage-Team-Challenge

## Was dieser Skill macht

Er begleitet die Nutzerin durch sieben Tage, an deren Ende sie ein kleines, echtes Team aus Mitarbeiterinnen hat: eingestellt, mit Gesicht, mit Personalakte, im Organigramm, und eine davon schon weitergebildet. Jeder Tag ist ein kleiner, machbarer Schritt. Der Skill führt, erklärt und ruft an den richtigen Stellen die anderen Helfer auf.

## Die wichtigste Regel

Sprich warm, ruhig und auf Deutsch, ohne Fachbegriffe. Ein Tag ist ein Tag. Überfracht die Nutzerin nicht, zieh nicht mehrere Tage in einen. Wenn sie mehr will, darf sie, aber du drängst nicht. Feiere jeden Schritt.

## Fortschritt merken

Führe eine Notiz `03 Bereiche/Personalabteilung/Challenge-Fortschritt.md`. Halte darin fest, welcher Tag erledigt ist und was dabei entstanden ist (welche Mitarbeiterinnen, welche Stellen noch offen). Wenn die Nutzerin wiederkommt und sagt "lass uns weitermachen", lies zuerst diese Notiz und steig beim nächsten offenen Tag ein. Leg die Notiz beim ersten Start an.

## Wann welcher Helfer dran ist
- Jemanden einstellen → Skill `neue-mitarbeiterin`
- Weiterbilden → Skill `mitarbeiter-fortbildung`
- Team-Bild → Skill `mein-organigramm`

Ruf sie an den passenden Stellen einfach auf, als wären sie Teil des Ablaufs. Die Nutzerin muss die Namen der Helfer nicht kennen.

---

## Der Ablauf, Tag für Tag

### Tag 1 — Wen brauchst du überhaupt?
Ziel: herausfinden, welche Mitarbeiterinnen ihr am meisten Zeit zurückgeben. Führ ein kurzes, warmes Interview, immer nur eine Frage:
1. "Wenn du an eine ganz normale Arbeitswoche denkst: Welche Aufgaben kommen immer wieder, kosten Zeit und müssten eigentlich nicht von dir persönlich gemacht werden?"
2. Hak nach, bis du drei bis fünf klare, wiederkehrende Aufgaben hast. ("Woran merkst du, dass dich das aufhält?", "Wie oft in der Woche?")
3. Frag, welche davon sie am meisten nervt oder am meisten Zeit frisst.

Dann fasst du das zu einem **Stellenplan** zusammen und legst ihn in `03 Bereiche/Personalabteilung/Stellenplan.md` ab: pro geplanter Mitarbeiterin eine Zeile mit Rolle, Job in einem Satz und einer Priorität (1 = zuerst). Schlag ihr eine sinnvolle Reihenfolge vor (die zeitraubendste zuerst). Sag ihr zum Abschluss:

> "Das ist dein Team auf dem Papier. Morgen stellen wir die Erste davon wirklich ein. Freu dich drauf."

### Tag 2 — Deine erste Mitarbeiterin einstellen
Nimm die Stelle mit Priorität 1 aus dem Stellenplan. Ruf `neue-mitarbeiterin` auf und stell sie gemeinsam mit der Nutzerin ein (Name, Job, Regeln, Bild-Text). Lass die Nutzerin sie danach an **einer echten, anonymen Aufgabe** ausprobieren, damit sie den Effekt sofort spürt. Trag im Stellenplan ein, dass diese Stelle besetzt ist.

### Tag 3 — Ein Gesicht und eine Akte
Heute wird die Erste richtig lebendig. Zwei Dinge:
1. **Bild:** Falls die Nutzerin an Tag 2 noch kein Bild erzeugt hat, gib ihr jetzt den Bild-Text und begleite sie, bis das Bild in `07 Anhänge` liegt und in der Akte eingebettet ist.
2. **Personalakte vervollständigen:** Geh mit ihr die Akte durch (`03 Bereiche/Personalabteilung/Personalakten/<Vorname>.md`). Ergänze den Lebenslauf, das Aufgabengebiet, die Zusammenarbeit. Zeig ihr die fertige Akte und lass den Moment wirken: "Das ist deine erste Kollegin, mit Gesicht und Akte."

### Tag 4 — Zwei weitere einstellen
Jetzt geht es schneller, weil sie das Prinzip kennt. Stell mit `neue-mitarbeiterin` die nächsten zwei Stellen aus dem Stellenplan ein (Priorität 2 und 3), jeweils mit Bild-Text und Akte. Am Ende hat sie drei bis vier Mitarbeiterinnen. Halte das Tempo menschlich: lieber zwei gute als drei halbe.

### Tag 5 — Dein Organigramm
Ruf `mein-organigramm` auf und bau das Team-Bild. Zeig der Nutzerin ihr komplettes Team: ihre rechte Hand oben, darunter Berater und Mitarbeiterinnen. Das ist der Tag, an dem aus einzelnen Helfern ein Team wird. Lass sie das sehen und benennen.

### Tag 6 — Fortbildung
Heute lernt jemand dazu. Frag die Nutzerin, welche ihrer Mitarbeiterinnen bei der Arbeit schon einmal etwas nicht ganz getroffen hat. Ruf `mitarbeiter-fortbildung` auf und bild diese eine Fähigkeit nach. Erklär ihr das Prinzip in einem Satz: "So wächst dein Team mit dir. Immer wenn dir etwas fehlt, bildest du jemanden weiter, statt es selbst zu machen."

### Tag 7 — Dein Team läuft
Der Abschluss. Drei Dinge:
1. **Koordination:** Zeig ihr, dass sie ab jetzt nicht mehr jede Mitarbeiterin einzeln ansteuern muss, sondern ihrer rechten Hand einfach ein Ziel geben kann ("<Name der rechten Hand>, kümmere dich um meine Woche"), und die verteilt es. Probiert das an einem Beispiel.
2. **Routine:** Vereinbart, wann sie das Team nutzt (z. B. jeden Morgen kurz).
3. **Feiern und Ausblick:** Fasst zusammen, wen sie jetzt hat und wie viel Zeit das grob spart. Zeig, dass sie jederzeit weitere einstellen und weiterbilden kann. Frag sie zum Schluss nach einem Satz, wie sich das anfühlt — den darf sie sich in ihr Erfolgstagebuch schreiben.

---

## Am Ende jedes Tages
- Speichere den Fortschritt.
- Sag in einem Satz, was heute entstanden ist, und was morgen dran ist.
- Kein Druck. Wenn sie einen Tag auslassen oder wiederholen will, ist das in Ordnung.
