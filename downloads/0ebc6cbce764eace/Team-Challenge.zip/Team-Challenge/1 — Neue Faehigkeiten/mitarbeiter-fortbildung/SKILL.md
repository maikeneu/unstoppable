---
name: mitarbeiter-fortbildung
description: Bildet eine deiner Mitarbeiterinnen weiter. Sie lernt eine neue Fähigkeit dazu, wird darin besser, und der neue Stand kommt in ihre Personalakte. Aktiviere bei "schick <Name> auf Fortbildung", "bilde <Name> weiter", "<Name> soll etwas dazulernen", "<Name> kann etwas noch nicht", "meine Mitarbeiterin verbessern", "Ich möchte eine meiner Mitarbeiterinnen weiterbilden", "meine Mitarbeiterin weiterbilden".
user-invocable: true
---

# Eine Mitarbeiterin weiterbilden

## Was dieser Skill macht

Er bringt einer bestehenden Mitarbeiterin etwas Neues bei. Genau wie ein Mensch im Job wächst, wächst auch sie: Sie lernt eine Fähigkeit dazu oder wird in ihrer Aufgabe besser. Danach kann sie mehr als vorher, und ihre Personalakte hält fest, was sie gelernt hat und wann.

## Die wichtigste Regel

Sprich warm und auf Deutsch, ohne Fachbegriffe. Stell immer nur eine Frage. Du veränderst hier eine bestehende Mitarbeiterin, du baust keine neue.

## Ablauf

### Schritt 1: Wen und was?
Wenn aus dem Satz der Nutzerin noch nicht klar ist, wen sie meint oder was diese lernen soll, frag genau eine Frage:

> "Gern. Wen möchtest du weiterbilden, und was soll sie dazulernen oder besser können?"

Finde die Mitarbeiterin: ihr Kopf liegt unter `.claude/skills/mitarbeiter-<kurzname>/`, ihre Akte unter `03 Bereiche/Personalabteilung/Personalakten/<Vorname>.md`. Wenn es mehrere mit ähnlichem Namen gibt, frag kurz nach, welche gemeint ist.

### Schritt 2: Kurz verstehen
Stell nur, was du brauchst, eine Frage nach der anderen:
- "Woran hast du gemerkt, dass ihr das noch fehlt? Hast du ein Beispiel?" (Damit du die Lücke genau triffst.)
- "Wie soll sie es künftig machen? Gibt es eine Regel oder ein Vorbild dafür?"

### Schritt 3: Womit soll sie lernen?
Frag nach dem Lernmaterial, eine Frage:

> "Womit soll sie das lernen? Du kannst mir etwas geben: eine Notiz oder Vorlage aus deinem zweiten Gehirn, zwei oder drei gute Beispiele von dir, den Text oder das Transkript eines Videos oder Artikels (leg ihn einfach in deine Inbox), oder ein Buch, das ich kenne. Wenn du nichts zur Hand hast, ist das auch in Ordnung, dann arbeite ich mit dem, was du mir eben erzählt hast."

So gehst du mit der Quelle um:
- Nennt sie eine Notiz oder Vorlage aus dem Vault: lies sie vollständig.
- Legt sie etwas in die Inbox (`01 Inbox/`): lies es von dort.
- Gibt sie dir einen Link: versuch ihn zu lesen. Wenn du nicht an den Inhalt kommst, sag es ehrlich und bitte sie, den Text oder das Transkript in die Inbox zu legen.
- Nennt sie ein Buch oder eine Methode, die du kennst: nutze dein Wissen dazu und sag ihr kurz, worauf du dich stützt.

Destilliere aus der Quelle das Wesentliche: drei bis sieben klare Merksätze oder Regeln, die genau zur Lücke aus Schritt 2 passen. In den Kopf der Mitarbeiterin kommt nur dieses Destillat, nicht der ganze Text. Merk dir die Quelle mit einem kurzen Namen, du trägst sie gleich mit in die Akte ein.

### Schritt 4: Die neue Fähigkeit einbauen (in ihren Kopf)
Öffne `.claude/skills/mitarbeiter-<kurzname>/SKILL.md` und arbeite die neue Fähigkeit sauber ein, statt einfach etwas anzuhängen:
- Ergänze oder schärfe die Schritte unter "So gehst du vor".
- Wenn eine neue feste Regel dazukommt, trag sie unter "Worauf du immer achtest" ein.
- Achte darauf, dass sich nichts widerspricht. Wenn die neue Fähigkeit eine alte Regel ersetzt, ändere die alte, statt beide stehen zu lassen.

### Schritt 5: In die Personalakte eintragen
Öffne `03 Bereiche/Personalabteilung/Personalakten/<Vorname>.md` und trag in der Tabelle "Weiterbildungen" eine neue Zeile ein:

| Datum | Neue Fähigkeit | Was sie jetzt besser kann |
| --- | --- | --- |
| <heutiges Datum> | <die Fähigkeit in wenigen Worten> | <der spürbare Unterschied> |

Hat sie mit einer Quelle gelernt, ergänze in der Spalte "Neue Fähigkeit" in Klammern, woraus: (gelernt aus: <kurzer Name der Quelle>). So sieht die Nutzerin später, worauf das Können ihrer Mitarbeiterin beruht.

Wenn die neue Fähigkeit ihr Aufgabengebiet wirklich erweitert, ergänze auch den Abschnitt "Aufgabengebiet" um einen Satz. Übertreib es nicht, halte die Akte ehrlich.

### Schritt 6: Kurz prüfen und übergeben
Prüf still: Läuft ihr Job jetzt runder, ohne dass etwas Altes kaputtgegangen ist? Dann sag der Nutzerin Bescheid, zum Beispiel:

> "**<Name>** hat dazugelernt: <Fähigkeit in einem Satz>. Ab sofort macht sie <der Unterschied>. Ich habe es in ihrer Akte unter Weiterbildungen vermerkt. Probier sie gleich einmal daran aus."

## Ein schöner Nebeneffekt
Über die Zeit erzählt die Weiterbildungs-Tabelle in jeder Akte die Geschichte, wie das Team mit der Nutzerin gewachsen ist. Das darfst du ihr ruhig einmal spiegeln, wenn eine Mitarbeiterin schon mehrere Fortbildungen hat.

## NICHT nutzen für
- Eine ganz neue Mitarbeiterin einstellen. Dafür gibt es `neue-mitarbeiterin`.
- Einen Berater ändern. Dafür öffnest du den Berater direkt.
