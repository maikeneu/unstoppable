---
name: mein-organigramm
description: Zeigt und aktualisiert das Organigramm deines Teams. Erstellt eine Übersicht, wer zu deinem Team gehört, wer wen beauftragt und wer welche Aufgabe hat. Aktiviere bei "zeig mir mein Organigramm", "wie sieht mein Team aus", "aktualisiere mein Organigramm", "wer gehört zu meinem Team", "Team-Übersicht".
user-invocable: true
---

# Mein Organigramm

## Was dieser Skill macht

Er zeigt der Nutzerin ihr Team als Bild und hält es aktuell. So sieht sie auf einen Blick, wer für sie arbeitet: ihre rechte Hand oben, darunter ihre Berater und ihre Mitarbeiterinnen. Das Organigramm liegt in `03 Bereiche/Personalabteilung/Organigramm.md`.

## Woher du weißt, wer zum Team gehört

Die Wahrheit über das Team steht an drei Stellen. Lies alle drei, bevor du das Organigramm baust:

1. `.claude/skills/` — jeder Ordner, der mit `berater-` beginnt, ist ein Berater; jeder, der mit `mitarbeiter-` beginnt, ist eine Mitarbeiterin. Das ist die verlässlichste Quelle. **Achtung, zwei Ausnahmen:** die Ordner `mitarbeiter-challenge` und `mitarbeiter-fortbildung` sind Helfer-Werkzeuge, keine Mitarbeiterinnen — überspring sie immer. Im Zweifel gilt: eine echte Mitarbeiterin hat eine Personalakte unter `03 Bereiche/Personalabteilung/Personalakten/`; die beiden Helfer haben keine.
2. `03 Bereiche/Personalabteilung/Personalakten/` — die Akten der Mitarbeiterinnen (Rolle, Abteilung).
3. `00 Kontext/Mein Team.md` und `CLAUDE.md` — dort steht der Name der rechten Hand.

Wenn eine Quelle der anderen widerspricht, richte dich nach den vorhandenen Ordnern in `.claude/skills/` und bring die anderen Stellen danach in Ordnung.

## Ablauf

### Schritt 1: Team einlesen
Sammle: den Namen der rechten Hand, alle Berater (Name + wofür), alle Mitarbeiterinnen (Name + Job + Abteilung).

### Schritt 2: Das Bild bauen
Öffne `03 Bereiche/Personalabteilung/Organigramm.md` und schreib den Mermaid-Block neu. Halte dich an dieses Muster, so bleibt es einheitlich und in den Marken-Farben:

```mermaid
%%{init: {'theme':'base','themeVariables':{'lineColor':'#CBB6A5','primaryTextColor':'#211B17','primaryBorderColor':'#E7DCCD'}}}%%
graph TD
    CHEF["👑 <Name der Nutzerin><br/>(die Chefin)"]:::chef
    RH["🤝 <Name der rechten Hand><br/>(rechte Hand)"]:::rh
    CHEF --> RH
    RH --> BERATER["💡 Berater"]:::gruppe
    RH --> TEAM["⚙️ Mitarbeiterinnen"]:::gruppe

    BERATER --> B1["<Beratername> — <wofür>"]:::person
    %% eine Zeile pro Berater

    TEAM --> M1["<Mitarbeiterin> — <Job>"]:::person
    %% eine Zeile pro Mitarbeiterin

    classDef chef fill:#C96B2C,stroke:#A85A2A,color:#FCFAF7;
    classDef rh fill:#E7DCCD,stroke:#C96B2C,color:#211B17;
    classDef gruppe fill:#F4F0EA,stroke:#CBB6A5,color:#7A6E60;
    classDef person fill:#FFFFFF,stroke:#E7DCCD,color:#211B17;
```

**Zwei feste Regeln fürs Bild, nicht ändern:** (1) Lass die `%%{init}%%`-Zeile immer stehen — sie gibt dem Organigramm die Marken-Farben und die warmen Verbindungslinien. (2) Nutze für die Kästchen immer eckige Klammern `["..."]`, nie runde `("...")` — bei runden schneidet die Grafik längere Namen ab.

Verlink die Mitarbeiterinnen unter dem Bild in der Liste "Meine Mitarbeiterinnen" mit ihrer Personalakte (`[[<Vorname>]]`). Wenn es (noch) keine Berater oder keine Mitarbeiterinnen gibt, lass die jeweilige Beispielzeile weg und schreib in die Liste einen freundlichen Hinweis, wie man welche baut.

### Schritt 3: Zeigen und erklären
Sag der Nutzerin in einem Satz, wie ihr Team gerade aussieht, und dass sie das Bild in ihrer Notiz `Organigramm` sieht (in Obsidian wird es als Grafik gezeichnet). Zum Beispiel:

> "So sieht dein Team gerade aus: **<Name der rechten Hand>** koordiniert, dazu hast du <Zahl> Berater und <Zahl> Mitarbeiterinnen. Du findest das Bild in deiner Personalabteilung unter **Organigramm**. Wenn du jemanden dazunehmen willst, sag einfach ‚ich brauche eine neue Mitarbeiterin'."

## Wichtig
- Sprich warm und auf Deutsch, ohne Fachbegriffe. Sag nicht "Mermaid" oder "Code" zur Nutzerin, sag "das Bild deines Teams".
- Ändere nur den Organigramm-Block, lösch keine Notizen und keine Akten.
